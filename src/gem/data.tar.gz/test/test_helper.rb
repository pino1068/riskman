require 'stringio'
require 'test/unit'
require File.dirname(__FILE__) + '/../lib/riskman'
